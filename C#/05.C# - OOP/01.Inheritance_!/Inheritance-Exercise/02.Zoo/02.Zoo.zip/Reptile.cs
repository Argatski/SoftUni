﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zoo
{
    public class Reptile : Animal
    {
        //Constructor
        public Reptile(string name)
            : base(name)
        {
        }

    }
}
