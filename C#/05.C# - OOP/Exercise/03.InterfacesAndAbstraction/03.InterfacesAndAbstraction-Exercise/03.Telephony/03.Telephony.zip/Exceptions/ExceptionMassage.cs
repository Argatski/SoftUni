﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public class ExceptionMassage
    {
        public static string invalidNumber = "Invalid number!";
        public static string invalidURL = "Invalid URL!";
    }
}
