﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person = new Person("Pesho",25);
            Person person1 = new Person("Gosho",18);
            Person person2 = new Person("Stamat",43);

        }
    }
}
