﻿namespace Raiding.Exceptions
{
    public static class InvalidInput
    {
        public const string InvalidHero = "Invalid hero!";
    }
}
