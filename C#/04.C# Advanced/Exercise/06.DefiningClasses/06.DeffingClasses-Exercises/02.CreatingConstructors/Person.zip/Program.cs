﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
           /* Person firstPerson = new Person();
            Person secondPerson = new Person(25);
            Person thirdPerson = new Person("Stamat", 45);*/
        }
    }
}
