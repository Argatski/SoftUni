﻿namespace PlanetWars.Models.MilitaryUnits.Entities
{
    public class StormTroopers : MilitaryUnit
    {
        private const double costStorm = 2.5;
        public StormTroopers() : base(costStorm)
        {
        }
    }
}
