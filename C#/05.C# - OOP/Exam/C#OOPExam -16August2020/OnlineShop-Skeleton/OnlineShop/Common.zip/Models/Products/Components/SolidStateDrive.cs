﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OnlineShop.Models.Products.Components
{
    public class SolidStateDrive : Component
    {
        private const double SolidStateDriveMultiplier = 1.20;
        public SolidStateDrive(int id, string manufacturer, string model, decimal price, double overallPerformence, int generation) : base(id, manufacturer, model, price, overallPerformence, generation)
        {
        }
        public override double OverallPerformance => base.OverallPerformance*SolidStateDriveMultiplier;
    }
}
