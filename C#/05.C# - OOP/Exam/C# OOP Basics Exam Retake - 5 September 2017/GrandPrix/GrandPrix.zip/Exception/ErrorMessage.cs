﻿public static class ErrorMessage
{
    public const string BlownTyre = "Blown Tyre";

    public const string OutOfFuel = "Out of fuel";
}