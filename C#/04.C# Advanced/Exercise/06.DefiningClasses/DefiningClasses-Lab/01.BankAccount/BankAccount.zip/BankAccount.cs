﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankAccount
{
    public class BankAccount
    {
        //Prive fields
        private int id;
        private decimal balance;

        //Properties
        public int Id { get; set; }
        public decimal Balance { get; set; }
    }
}
