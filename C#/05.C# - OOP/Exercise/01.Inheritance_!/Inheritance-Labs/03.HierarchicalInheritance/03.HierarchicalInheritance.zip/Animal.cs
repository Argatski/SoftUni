﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    public class Animal //Base Class (Parent Class)
    {
        public void Eat()
        {
            Console.WriteLine("eating…");
        }
    }
}
