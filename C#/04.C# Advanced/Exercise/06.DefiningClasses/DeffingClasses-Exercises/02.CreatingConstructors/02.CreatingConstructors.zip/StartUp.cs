﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            /*
             //Instance
            Person firstPerson = new Person();
            Person secondPerson = new Person(25);
            Person thirdPerson = new Person("Stamat", 45);
            
            //Print result
            Console.WriteLine(firstPerson);
            Console.WriteLine(secondPerson);
            Console.WriteLine(thirdPerson);
            */
        }
    }
}
