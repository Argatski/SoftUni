﻿namespace FoodShortage
{
    public interface IIdentifiable
    {
        public string Id { get; }
        
    }
}
