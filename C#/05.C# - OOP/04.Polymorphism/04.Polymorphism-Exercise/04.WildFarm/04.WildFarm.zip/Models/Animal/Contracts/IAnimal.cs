﻿namespace WildFarm.Models.Animal.Contracts
{
    public interface IAnimal
    {
        string Name { get; }
        double Weight { get; }
    }
}
