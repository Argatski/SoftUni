﻿namespace BirthdayCelebrations
{
    public interface IMammal
    {
        public string Name { get; }
        public string Birthdate { get; }
    }
}
