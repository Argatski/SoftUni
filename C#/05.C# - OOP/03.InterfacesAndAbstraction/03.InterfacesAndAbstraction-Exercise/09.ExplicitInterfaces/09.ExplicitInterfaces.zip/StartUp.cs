﻿namespace ExplicitInterfaces
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var engine = new Engine.Engine();

            engine.Run();
        }
    }
}
