﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    public class DarkWizard : Wizard
    {
        //Constructor
        public DarkWizard(string username, int level)
            : base(username, level)
        {
        }
    }
}
