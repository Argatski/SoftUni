﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    public class Cat: Animal //Child class, Derived class.Inheritance Cat->Animal
    {
        public void Meow()
        {
            Console.WriteLine("meowing…");
        }
    }
}
