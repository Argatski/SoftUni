﻿namespace Operations
{
    public class MathOperations
    {
        public int Add(int num1, int num2)
        {
            int num = num1 + num2;
            return num;
        }
        public double Add(double a, double b, double c)
        {
            return a + b + c;
        }
        public decimal Add(decimal d1, decimal d2, decimal d3)
        {
            return d1 + d2 + d3;
        }
    }
}
