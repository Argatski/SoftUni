﻿namespace WildFarm.Models.Animal.Contracts
{
    public interface ISoundProducable
    {
        string Sound();
    }
}
