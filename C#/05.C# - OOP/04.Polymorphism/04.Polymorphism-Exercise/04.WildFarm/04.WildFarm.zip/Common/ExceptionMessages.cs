﻿namespace WildFarm.Common
{
    public static class ExceptionMessages
    {
        public const string InvalidType = "Invalid Type";
    }
}
