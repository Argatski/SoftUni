﻿namespace CollectionHierarchy.Contracts
{
    public interface IAddCollections
    {
        int Add(string item);
    }
}
