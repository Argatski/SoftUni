﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    public class Dog : Animal //Child class, Derived class.Inheritance Dog->Animal
    {
        public void Bark()
        {
            Console.WriteLine("barking…");
        }
    }
}
