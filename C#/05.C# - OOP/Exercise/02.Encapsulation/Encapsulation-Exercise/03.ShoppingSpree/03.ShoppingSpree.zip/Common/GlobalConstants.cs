﻿namespace ShoppingSpree
{
    public static class GlobalConstants
    {
        public const string EmptyNameExcMsg = "Name cannot be empty";
        public const string EmptyMoneyExcMsg = "Money cannot be negative";
    }
}
