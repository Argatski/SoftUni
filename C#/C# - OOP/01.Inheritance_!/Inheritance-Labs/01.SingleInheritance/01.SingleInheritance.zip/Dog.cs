﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm

{
    public class Dog : Animal //Inheritance
    {
        public void Bark()
        {
            Console.WriteLine("barking…");
        }

    }
}
