﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    public class Puppy : Dog //Inheritance Dog -> Dog ->Animal
    {
        public void Weep()
        {
            Console.WriteLine("weeping…");
        }
    }
}
