﻿
namespace SoftUni    
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}

/*PowerShell command:
 dotnet ef dbcontext scaffold "Server=DESKTOP-P22IBOP\MSSQLSERVER_2023;Database=SoftUni;Integrated Security=True;TrustServerCertificate=True" Microsoft.EntityFrameworkCore.SqlServer -o Models
 */