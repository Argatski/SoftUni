﻿namespace PlanetWars.Models.MilitaryUnits.Entities
{
    public class SpaceForces : MilitaryUnit
    {
        private const double costSpace = 11;
        public SpaceForces() : base(costSpace)
        {
        }
    }
}
